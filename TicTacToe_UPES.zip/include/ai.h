#ifndef AI_H
#define AI_H
#include "game.h"
void computer_move(char board[BOARD_SIZE][BOARD_SIZE]);
#endif
