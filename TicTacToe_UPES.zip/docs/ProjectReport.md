# Project Report — TIC TAC TOE

## 1. Title Page
**Project Title:** TIC TAC TOE
**Student:** Krishna Grover
**Roll No:** 590023545
**Course:** B.Tech CSE
**University:** UPES
**Instructor:** Dr. Tanu Singh

## 2. Abstract
This project implements a console-based Tic-Tac-Toe game in C. It demonstrates modular programming, separation of interface and logic, a Minimax-based unbeatable AI (God mode), and comprehensive documentation. The repository follows the UPES Major Project structure.

## 3. Problem Definition
Design and implement a robust Tic-Tac-Toe program that supports human vs computer play, two difficulty levels, reliable input handling, and clear documentation suitable for automated evaluation.

## 4. System Design
Modules:
- main.c — program entry and loop
- game.c — game logic, board operations, I/O
- ai.c — computer opponent (heuristic + Minimax)
- include/*.h — headers

## 5. Implementation Details
The AI uses Minimax in God mode (difficulty 2). In standard mode, it uses heuristic moves with immediate win/block checks.

## 6. Testing & Results
Compiled with: `gcc -Iinclude -std=c11 -Wall src/*.c -o main`
Tested scenarios: player win, computer win, draw, invalid input.

## 7. Conclusion & Future Work
Project meets rubric: modularity, documentation, compile-time safety. Future work: GUI, persistent leaderboard, minimax pruning improvements.

## 8. References
Course materials, C standard library documentation.

## 9. Appendix
Sample inputs and outputs are included as sample_input.txt.
