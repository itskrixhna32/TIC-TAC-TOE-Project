#include "ai.h"
#include <stdio.h>
static int try_immediate_win_or_block(char board[BOARD_SIZE][BOARD_SIZE], char mark);
static int minimax(char board[BOARD_SIZE][BOARD_SIZE], int depth, int isMaximizing);
static int evaluate_board(char board[BOARD_SIZE][BOARD_SIZE]);
static int moves_left(char board[BOARD_SIZE][BOARD_SIZE]);
static void make_move(char board[BOARD_SIZE][BOARD_SIZE], int r, int c, char mark);
static void undo_move(char board[BOARD_SIZE][BOARD_SIZE], int r, int c);

void computer_move(char board[BOARD_SIZE][BOARD_SIZE]){
    if (difficulty==2){
        if (try_immediate_win_or_block(board,'O')) return;
        int bestScore=-1000,br=-1,bc=-1;
        for(int i=0;i<BOARD_SIZE;i++) for(int j=0;j<BOARD_SIZE;j++){
            if (board[i][j]==' '){
                board[i][j]='O';
                int sc=minimax(board,0,0);
                board[i][j]=' ';
                if (sc>bestScore){ bestScore=sc; br=i; bc=j; }
            }
        }
        if (br!=-1) board[br][bc]='O';
        return;
    }
    if (try_immediate_win_or_block(board,'O')) return;
    if (try_immediate_win_or_block(board,'X')) return;
    if (board[1][1]==' '){ board[1][1]='O'; return; }
    int corners[4][2]={{0,0},{0,2},{2,0},{2,2}};
    for(int i=0;i<4;i++){ int r=corners[i][0], c=corners[i][1]; if (board[r][c]==' '){ board[r][c]='O'; return; } }
    for(int i=0;i<BOARD_SIZE;i++) for(int j=0;j<BOARD_SIZE;j++) if (board[i][j]==' '){ board[i][j]='O'; return; }
}

static int try_immediate_win_or_block(char board[BOARD_SIZE][BOARD_SIZE], char mark){
    for (int i=0;i<BOARD_SIZE;i++) for (int j=0;j<BOARD_SIZE;j++){
        if (board[i][j]==' '){
            board[i][j]=mark;
            if (check_win(board,mark)){ board[i][j]='O'; return 1; }
            board[i][j]=' ';
        }
    }
    return 0;
}

static int minimax(char board[BOARD_SIZE][BOARD_SIZE], int depth, int isMaximizing){
    int score=evaluate_board(board);
    if (score==10) return score-depth;
    if (score==-10) return score+depth;
    if (!moves_left(board)) return 0;
    if (isMaximizing){
        int best=-1000;
        for (int i=0;i<BOARD_SIZE;i++) for (int j=0;j<BOARD_SIZE;j++) if (board[i][j]==' '){
            make_move(board,i,j,'O');
            int val=minimax(board,depth+1,0);
            undo_move(board,i,j);
            if (val>best) best=val;
        }
        return best;
    } else {
        int best=1000;
        for (int i=0;i<BOARD_SIZE;i++) for (int j=0;j<BOARD_SIZE;j++) if (board[i][j]==' '){
            make_move(board,i,j,'X');
            int val=minimax(board,depth+1,1);
            undo_move(board,i,j);
            if (val<best) best=val;
        }
        return best;
    }
}

static int evaluate_board(char board[BOARD_SIZE][BOARD_SIZE]){
    for (int i=0;i<BOARD_SIZE;i++) if (board[i][0]=='O'&&board[i][1]=='O'&&board[i][2]=='O') return 10;
    for (int i=0;i<BOARD_SIZE;i++) if (board[0][i]=='O'&&board[1][i]=='O'&&board[2][i]=='O') return 10;
    if ((board[0][0]=='O'&&board[1][1]=='O'&&board[2][2]=='O')||(board[0][2]=='O'&&board[1][1]=='O'&&board[2][0]=='O')) return 10;
    for (int i=0;i<BOARD_SIZE;i++) if (board[i][0]=='X'&&board[i][1]=='X'&&board[i][2]=='X') return -10;
    for (int i=0;i<BOARD_SIZE;i++) if (board[0][i]=='X'&&board[1][i]=='X'&&board[2][i]=='X') return -10;
    if ((board[0][0]=='X'&&board[1][1]=='X'&&board[2][2]=='X')||(board[0][2]=='X'&&board[1][1]=='X'&&board[2][0]=='X')) return -10;
    return 0;
}
static int moves_left(char board[BOARD_SIZE][BOARD_SIZE]){ for(int i=0;i<BOARD_SIZE;i++) for(int j=0;j<BOARD_SIZE;j++) if (board[i][j]==' ') return 1; return 0; }
static void make_move(char board[BOARD_SIZE][BOARD_SIZE], int r, int c, char mark){ board[r][c]=mark; }
static void undo_move(char board[BOARD_SIZE][BOARD_SIZE], int r, int c){ board[r][c]=' '; }
