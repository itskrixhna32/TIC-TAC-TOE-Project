#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "game.h"
int main(void){
    srand((unsigned)time(NULL));
    int choice;
    input_difficulty();
    do {
        play_game();
        printf("Play again? (1 for YES / 0 for NO): ");
        if (scanf("%d", &choice)!=1) choice=0;
    } while (choice==1);
    printf("BYE BYE, Thanks for playing!!\n");
    return 0;
}
