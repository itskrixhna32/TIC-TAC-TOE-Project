#include <stdio.h>
#include <stdlib.h>
#include "game.h"
#include "ai.h"
Score score = {.player=0,.computer=0,.draw=0};
int difficulty=1;
static void init_board(char board[BOARD_SIZE][BOARD_SIZE]){
    for(int i=0;i<BOARD_SIZE;i++) for(int j=0;j<BOARD_SIZE;j++) board[i][j]=' ';
}
static char random_start_player(void){
    return (rand()%2==0)?'X':'O';
}
void play_game(void){
    char board[BOARD_SIZE][BOARD_SIZE];
    init_board(board);
    char current_player = random_start_player();
    print_board(board);
    while(1){
        if (current_player=='X'){
            player_move(board);
            print_board(board);
            if (check_win(board,'X')){ score.player++; printf("Congratulations you have won!!\\n"); break;}
            current_player='O';
        } else {
            computer_move(board);
            print_board(board);
            if (check_win(board,'O')){ score.computer++; printf("Computer has won!!\\n"); break;}
            current_player='X';
        }
        if (check_draw(board)){ score.draw++; print_board(board); printf("It's a draw!\\n"); break;}
    }
}
int is_valid_move(char board[BOARD_SIZE][BOARD_SIZE], int row, int col){
    if (row<1||row>BOARD_SIZE||col<1||col>BOARD_SIZE) return 0;
    return board[row-1][col-1]==' ';
}
void player_move(char board[BOARD_SIZE][BOARD_SIZE]){
    int row=0,col=0;
    do {
        printf("Player X turn. Enter row and column (1-3) for X: ");
        if (scanf("%d %d",&row,&col)!=2){ int c; while((c=getchar())!='\\n' && c!=EOF){} row=col=0; }
    } while(!is_valid_move(board,row,col));
    board[row-1][col-1]='X';
}
int check_win(char board[BOARD_SIZE][BOARD_SIZE], char player){
    for(int i=0;i<BOARD_SIZE;i++){
        if (board[i][0]==player && board[i][1]==player && board[i][2]==player) return 1;
        if (board[0][i]==player && board[1][i]==player && board[2][i]==player) return 1;
    }
    if ((board[0][0]==player && board[1][1]==player && board[2][2]==player) ||
        (board[0][2]==player && board[1][1]==player && board[2][0]==player)) return 1;
    return 0;
}
int check_draw(char board[BOARD_SIZE][BOARD_SIZE]){
    for(int i=0;i<BOARD_SIZE;i++) for(int j=0;j<BOARD_SIZE;j++) if (board[i][j]==' ') return 0;
    return 1;
}
void print_board(char board[BOARD_SIZE][BOARD_SIZE]){
    clear_screen();
    printf("\\nScore - Player X: %d | Computer O: %d | Draws: %d\\n", score.player, score.computer, score.draw);
    printf("TIC TAC TOE\\n");
    for(int i=0;i<BOARD_SIZE;i++){
        printf("\\n");
        for(int j=0;j<BOARD_SIZE;j++){
            printf(" %c ", board[i][j]);
            if (j<BOARD_SIZE-1) printf("|");
        }
        if (i<BOARD_SIZE-1) printf("\\n---+---+---");
    }
    printf("\\n\\n");
}
void input_difficulty(void){
    while(1){
        printf("\\nselect difficulty level:\\n1. Human (Standard)\\n2. God (Impossible to win)\\nEnter Your Choice: ");
        if (scanf("%d",&difficulty)!=1){ int c; while((c=getchar())!='\\n' && c!=EOF){} difficulty=1; }
        if (difficulty!=1 && difficulty!=2) printf("\\n\\n Incorrect choice Enter 1/2!!\\n"); else break;
    }
}
void clear_screen(void){
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}
